window.addEventListener('scroll', function() {
    const navbar = document.getElementById('navbar');
    if (window.scrollY > 50) {
        navbar.classList.add('scrolled');
    } else {
        navbar.classList.remove('scrolled');
    }
});

// Stats Counter Animation
const counters = document.querySelectorAll('.counter');
let triggered = false;

window.addEventListener('scroll', () => {
    const statsSection = document.getElementById('stats');
    if (statsSection.getBoundingClientRect().top < window.innerHeight && !triggered) {
        counters.forEach(c => {
            let target = +c.dataset.target;
            let count = 0;
            let update = () => {
                if (count < target) {
                    count += Math.ceil(target / 40);
                    c.innerText = count;
                    setTimeout(update, 40);
                } else {
                    c.innerText = target + "+";
                }
            };
            update();
        });
        triggered = true;
    }
});
const headerTemplate = `
<header id="real-header">
    <div class="nav-container">
        <a href="home.html" class="logo-text">EVENT<span class="gold-text">PRO</span></a>
        <ul class="nav-links">
            <li><a href="home.html">Home</a></li>
            <li><a href="services.html">Services</a></li>
            <li><a href="impact.html">Impact</a></li>
            <li><a href="contact.html">Contact</a></li>
        </ul>
    </div>
</header>`;

// ... (keep your footerTemplate here) ...

document.addEventListener('DOMContentLoaded', () => {
    // 1. Inject Header into the 'navbar' div
    const navSpace = document.getElementById('navbar');
    if (navSpace) {
        navSpace.innerHTML = headerTemplate;
    }

    // 2. Inject Footer into the 'main-footer' div
    const footerSpace = document.getElementById('main-footer');
    if (footerSpace) {
        footerSpace.innerHTML = footerTemplate;
    }

    // 3. Scroll Effect Logic
    window.onscroll = function() {
        const header = document.getElementById('real-header');
        if (header) {
            if (window.pageYOffset > 50) {
                header.classList.add("scrolled");
            } else {
                header.classList.remove("scrolled");
            }
        }
    };
});