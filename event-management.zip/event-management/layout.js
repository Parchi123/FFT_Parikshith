// 1. Navigation Template Generator
const generateNav = () => {
    // Force a fresh check of the login status
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    
    return `
    <header id="main-header">
        <div class="nav-container">
            <a href="home.html" class="logo-box">
                <i class="fas fa-crown gold-icon"></i>
                <span class="logo-text">EVENT<span class="gold-text">PRO</span></span>
            </a>
            <ul class="nav-links">
                <li><a href="home.html">Home</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="impact.html">Impact</a></li>
                <li><a href="gallery.html">Gallery</a></li>
                <li><a href="contact.html">Contact</a></li>
                <li class="auth-item">
                    ${isLoggedIn 
                        ? `<button onclick="handleLogout()" class="nav-btn-gold">Logout</button>` 
                        : `<a href="login.html" class="nav-btn-gold">Login</a>`
                    }
                </li>
            </ul>
        </div>
    </header>`;
};

// 2. Footer Template
const footerTemplate = `
<footer class="footer">
    <div class="footer-grid">
        <div class="footer-about">
            <h3>EVENT<span class="gold-text">PRO</span></h3>
            <p>Premium Event Management Company delivering excellence for over 15 years.</p>
            <div class="socials">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>
        <div class="footer-links">
            <h4>Quick Links</h4>
            <ul>
                <li><a href="home.html">Home</a></li>
                <li><a href="services.html">Services</a></li>
                <li><a href="gallery.html">Gallery</a></li>
                <li><a href="contact.html">Contact</a></li>
            </ul>
        </div>
        <div class="footer-contact">
            <h4>Contact Info</h4>
            <p><i class="fas fa-envelope gold-icon"></i> support@eventpro.com</p>
            <p><i class="fas fa-phone gold-icon"></i> +91 9876543210</p>
            <p><i class="fas fa-map-marker-alt gold-icon"></i> New Delhi, India</p>
        </div>
    </div>
    <div class="footer-bottom">
        <p>© 2026 EventPro | All Rights Reserved</p>
    </div>
</footer>`;

// 3. Global Logout Handler
window.handleLogout = () => {
    localStorage.removeItem('isLoggedIn');
    alert("Logged out successfully.");
    window.location.reload(); 
};

// 4. Component Injection Logic
const injectLayout = () => {
    const navContainer = document.getElementById('navbar');
    const footerContainer = document.getElementById('main-footer');

    if (navContainer) {
        // We call generateNav() here to get the dynamic HTML
        navContainer.innerHTML = generateNav();
        
        const header = document.getElementById('main-header');
        const isHomePage = window.location.pathname.includes('home.html') || window.location.pathname.endsWith('/');
        if (isHomePage && header) {
            header.classList.add('home-header');
        }
    }

    if (footerContainer) {
        footerContainer.innerHTML = footerTemplate;
    }
};

// 5. Scroll Listener for Header Effects
window.addEventListener('scroll', () => {
    const header = document.getElementById('main-header');
    if (header) {
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    }
});

// Run Injection on load
window.addEventListener('load', injectLayout);




// 1. Function to check if we should show the popup
const checkLoginPopup = () => {
    if (localStorage.getItem('showLoginSuccess') === 'true') {
        const modal = document.getElementById('loginModal');
        const welcomeText = document.getElementById('welcomeMessage');
        
        if (modal) {
            modal.style.display = 'flex';
            
            // Personalize the name from the email (e.g., niriksha@mail.com -> Niriksha)
            const email = localStorage.getItem('userEmail');
            if (email) {
                const name = email.split('@')[0];
                welcomeText.innerText = `Welcome back, ${name.charAt(0).toUpperCase() + name.slice(1)}. Your executive portal is now active.`;
            }
        }
        // Remove flag so it doesn't pop up again on refresh
        localStorage.removeItem('showLoginSuccess');
    }
};

// 2. Global function to close the modal
window.closeModal = () => {
    const modal = document.getElementById('loginModal');
    if (modal) modal.style.display = 'none';
};

// 3. Ensure this runs when the page is ready
// Add this inside your existing injectLayout function or window.onload
window.addEventListener('load', () => {
    // ... your existing layout injection ...
    checkLoginPopup(); 
});